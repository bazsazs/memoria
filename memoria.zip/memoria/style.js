// Memória játék logika
let cards = ['A', 'B', 'C', 'D', 'E', 'F', 'A', 'B', 'C', 'D', 'E', 'F'];
let flippedCards = [];
let matchedCards = [];

// Kezdő állapot beállítása
function initGame() {
  cards = shuffle(cards);
  renderGameBoard();
}

// Kártyák keverése
function shuffle(array) {
  return array.sort(() => Math.random() - 0.5);
}

// Kártyák megjelenítése
function renderGameBoard() {
  const gameBoard = document.getElementById('game-board');
  gameBoard.innerHTML = '';

  cards.forEach((value, index) => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.dataset.index = index;
    card.textContent = value;
    card.addEventListener('click', handleCardClick);
    gameBoard.appendChild(card);
  });
}

// Kártyára kattintás kezelése
function handleCardClick(event) {
  const clickedCard = event.target;
  const index = clickedCard.dataset.index;

  if (!flippedCards.includes(index) && flippedCards.length < 2) {
    flippedCards.push(index);
    flipCard(clickedCard);

    if (flippedCards.length === 2) {
      setTimeout(checkCardMatch, 1000);
    }
  }
}

// Kártya megfordítása
function flipCard(card) {
  card.style.backgroundColor = '#c40808';
  card.style.color = '#000000';
}

// Két kártya azonosságának ellenőrzése
function checkCardMatch() {
  const [index1, index2] = flippedCards;
  const card1 = document.querySelector(`[data-index="${index1}"]`);
  const card2 = document.querySelector(`[data-index="${index2}"]`);

  if (cards[index1] === cards[index2]) {
    matchedCards.push(index1, index2);

    if (matchedCards.length === cards.length) {
      setTimeout(() => {
        alert('Gratulálok! Nyertél!');
        initGame();
      }, 500);
    }
  } else {
    unflipCards(card1, card2);
  }

  flippedCards = [];
}

// Két kártya visszafordítása
function unflipCards(card1, card2) {
  setTimeout(() => {
    card1.style.backgroundColor = '#000000';
    card1.style.color = '#000000';
    card2.style.backgroundColor = '#000000';
    card2.style.color = '#000000';
  }, 500);
}

// Játék inicializálása
initGame();